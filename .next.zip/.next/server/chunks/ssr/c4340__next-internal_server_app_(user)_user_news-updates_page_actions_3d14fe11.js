module.exports=[52836,(a,b,c)=>{}];

//# sourceMappingURL=c4340__next-internal_server_app_%28user%29_user_news-updates_page_actions_3d14fe11.js.map