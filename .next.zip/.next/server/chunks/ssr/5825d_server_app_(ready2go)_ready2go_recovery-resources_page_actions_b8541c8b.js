module.exports=[63680,(a,b,c)=>{}];

//# sourceMappingURL=5825d_server_app_%28ready2go%29_ready2go_recovery-resources_page_actions_b8541c8b.js.map