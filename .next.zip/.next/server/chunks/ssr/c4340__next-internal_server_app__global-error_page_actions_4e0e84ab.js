module.exports=[48236,(a,b,c)=>{}];

//# sourceMappingURL=c4340__next-internal_server_app__global-error_page_actions_4e0e84ab.js.map