module.exports=[67124,(a,b,c)=>{}];

//# sourceMappingURL=c4340__next-internal_server_app_%28ready2go%29_ready2go_settings_page_actions_ed2b8dd0.js.map