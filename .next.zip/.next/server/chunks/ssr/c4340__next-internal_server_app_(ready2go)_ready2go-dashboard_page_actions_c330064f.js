module.exports=[25825,(a,b,c)=>{}];

//# sourceMappingURL=c4340__next-internal_server_app_%28ready2go%29_ready2go-dashboard_page_actions_c330064f.js.map