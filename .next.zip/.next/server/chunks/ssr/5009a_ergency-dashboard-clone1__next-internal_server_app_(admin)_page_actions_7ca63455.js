module.exports=[21123,(a,b,c)=>{}];

//# sourceMappingURL=5009a_ergency-dashboard-clone1__next-internal_server_app_%28admin%29_page_actions_7ca63455.js.map