module.exports=[60999,(a,b,c)=>{}];

//# sourceMappingURL=c4340__next-internal_server_app_%28user%29_user_alerts_page_actions_ea82d9bb.js.map