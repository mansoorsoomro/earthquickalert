module.exports=[16259,(a,b,c)=>{}];

//# sourceMappingURL=c4340__next-internal_server_app_%28user%29_user-dashboard_page_actions_f72d544a.js.map