module.exports=[6204,(a,b,c)=>{}];

//# sourceMappingURL=8d37f_next-internal_server_app_%28admin%29_preparedness-information_page_actions_7fe0b825.js.map