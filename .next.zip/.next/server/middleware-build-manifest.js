globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/9aace3e9da27e543.js",
    "static/chunks/4722c8e7b155f438.js",
    "static/chunks/fd37bf38aece5bf5.js",
    "static/chunks/0cacb6c08a1bff8c.js",
    "static/chunks/592d25b5d0a85e69.js",
    "static/chunks/turbopack-4e2ba6e286107ca5.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];