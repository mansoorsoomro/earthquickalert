globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/95f00_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_5e4e3d8b._.js",
    "static/chunks/95f00_next_dist_compiled_react-dom_afa69674._.js",
    "static/chunks/95f00_next_dist_compiled_react-server-dom-turbopack_081f181e._.js",
    "static/chunks/95f00_next_dist_compiled_next-devtools_index_541ac863.js",
    "static/chunks/95f00_next_dist_compiled_63aa3142._.js",
    "static/chunks/95f00_next_dist_client_048f4287._.js",
    "static/chunks/95f00_next_dist_d39e266e._.js",
    "static/chunks/95f00_@swc_helpers_cjs_95bc40da._.js",
    "static/chunks/Desktop_earthquick_emergency-dashboard-clone1_a0ff3932._.js",
    "static/chunks/turbopack-Desktop_earthquick_emergency-dashboard-clone1_b767fde9._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];