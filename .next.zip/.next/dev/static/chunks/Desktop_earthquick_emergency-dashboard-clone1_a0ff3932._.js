(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_5e4e3d8b._.js",
  "static/chunks/95f00_next_dist_compiled_react-dom_afa69674._.js",
  "static/chunks/95f00_next_dist_compiled_react-server-dom-turbopack_081f181e._.js",
  "static/chunks/95f00_next_dist_compiled_next-devtools_index_541ac863.js",
  "static/chunks/95f00_next_dist_compiled_63aa3142._.js",
  "static/chunks/95f00_next_dist_client_048f4287._.js",
  "static/chunks/95f00_next_dist_d39e266e._.js",
  "static/chunks/95f00_@swc_helpers_cjs_95bc40da._.js"
],
    source: "entry"
});
