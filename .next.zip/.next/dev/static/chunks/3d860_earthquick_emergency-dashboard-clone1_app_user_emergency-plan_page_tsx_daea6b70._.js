(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/95f00_6c8c60ab._.js",
  "static/chunks/Desktop_earthquick_emergency-dashboard-clone1_1e9b2abc._.js"
],
    source: "dynamic"
});
