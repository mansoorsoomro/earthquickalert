(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/95f00_88a3438c._.js",
  "static/chunks/Desktop_earthquick_emergency-dashboard-clone1_63e8c6dd._.js"
],
    source: "dynamic"
});
