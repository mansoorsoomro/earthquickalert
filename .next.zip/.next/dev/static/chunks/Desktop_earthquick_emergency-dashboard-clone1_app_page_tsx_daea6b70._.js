(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Desktop_earthquick_emergency-dashboard-clone1_6cec87d3._.js",
  "static/chunks/95f00_7d670021._.js"
],
    source: "dynamic"
});
