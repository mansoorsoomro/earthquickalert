(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/95f00_8f2f1482._.js",
  "static/chunks/Desktop_earthquick_emergency-dashboard-clone1_3e9c1715._.js"
],
    source: "dynamic"
});
