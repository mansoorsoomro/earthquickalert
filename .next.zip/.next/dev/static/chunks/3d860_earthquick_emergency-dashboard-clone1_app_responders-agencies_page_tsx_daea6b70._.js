(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Desktop_earthquick_emergency-dashboard-clone1_8369cb1d._.js",
  "static/chunks/95f00_dfb4881a._.js"
],
    source: "dynamic"
});
