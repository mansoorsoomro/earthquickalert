(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/95f00_f5a1524d._.js",
  "static/chunks/Desktop_earthquick_emergency-dashboard-clone1_ffc65fab._.js"
],
    source: "dynamic"
});
