(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/95f00_a3871319._.js",
  "static/chunks/Desktop_earthquick_emergency-dashboard-clone1_71276ccb._.js"
],
    source: "dynamic"
});
