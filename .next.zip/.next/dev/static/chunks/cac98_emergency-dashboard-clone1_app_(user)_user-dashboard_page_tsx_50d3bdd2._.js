(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Desktop_earthquick_emergency-dashboard-clone1_5c8d07a2._.js",
  "static/chunks/95f00_fa27debb._.js"
],
    source: "dynamic"
});
