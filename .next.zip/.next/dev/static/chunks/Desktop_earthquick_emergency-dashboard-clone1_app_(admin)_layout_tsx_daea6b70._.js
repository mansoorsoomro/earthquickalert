(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/95f00_04cad0b7._.js",
  "static/chunks/Desktop_earthquick_emergency-dashboard-clone1_150d5e63._.js"
],
    source: "dynamic"
});
