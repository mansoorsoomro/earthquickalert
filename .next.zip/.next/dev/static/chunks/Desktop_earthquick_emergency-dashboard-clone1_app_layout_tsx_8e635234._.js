(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__7e7e9f3e._.css",
  "static/chunks/Desktop_earthquick_emergency-dashboard-clone1_47b38e81._.js"
],
    source: "dynamic"
});
