(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Desktop_earthquick_emergency-dashboard-clone1_1c2adb8f._.js",
  "static/chunks/95f00_lucide-react_dist_esm_icons_79006bac._.js"
],
    source: "dynamic"
});
