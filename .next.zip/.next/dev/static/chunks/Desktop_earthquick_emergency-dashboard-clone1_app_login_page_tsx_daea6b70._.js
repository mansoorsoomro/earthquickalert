(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/95f00_eac375fd._.js",
  "static/chunks/Desktop_earthquick_emergency-dashboard-clone1_94a16223._.js"
],
    source: "dynamic"
});
