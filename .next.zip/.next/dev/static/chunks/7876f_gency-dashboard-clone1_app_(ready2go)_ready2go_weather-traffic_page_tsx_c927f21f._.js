(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Desktop_earthquick_emergency-dashboard-clone1_d96d25f6._.js",
  "static/chunks/95f00_60fb8d44._.js"
],
    source: "dynamic"
});
